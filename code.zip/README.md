# saml-proxy: A customized SATOSA SAML-SAML proxy on Fargate

Author: Matt Boyd

Created: 2020-06-14

This project contains contains code to automate the deployment of a SAML proxy that is configured to "Proxy" SAML assertions between an identity provider and the AWS Service Provider. 

Out of the box, the SAML proxy is configured to support AppStream customers that need to convert the format of the subject (NameID) from `username@domain.com` to `DOMAIN.COM\username` when their IdP cannot support this transformation. This specific transformation was needed for a customer that uses an MIT Kerberos cross-realm trust that is case-sensitive and would only work with the `SAMAccountName` format, but their `IdP` could only send the `NameID` in `UserPrincipalName` format with a lowercase domain.  Though this is likely an edge case, the proxy could also be configured to support a variety of other scenarios, such taking a a SAML attribute receivedd from the source IdP and passing that back to the AWS SP as the `NameID`, or enriching the response assertion by injecting addtional attributes from an external source (i.e. LDAP)

The project uses [SATOSA](https://github.com/IdentityPython/SATOSA), a identity proxy app that is largely based on pysaml2. The saml-proxy project contains a customized SATOSA SAML Frontend plugin that accepts unsolicited requests as well as a custom SATSOA microservice that can parse `UserNamePrincipal` (`username@domain.com`) formatted `NameID` and convert it to `SAMAccountName` (`DOMAIN.COM\username`) format with (optionally) an uppercase domain. **The custom SAML Frontend plugin and microservice are NOT part of the SATOSA code base.** The code for these customzations can be found in `satosa/micro_services` and `satosa/frontends` folders of this repo. 


# Key Features
- Fully automated - The setup of Saml-Proxy is full automated. Simply zip up the contents of this repo and upload to `code.zip` in an S3 bucket, then run the `cfn-pipeline.yml` template. A CodePipeline project is created that handles the rest. Details below.
- Minimal infrastructure - The app runs as a Fargate task behind an Application Load Balancer, within its own isolated VPC. 
- Simple setup - Configured out of the box to proxy requests to the AWS SP from your IdP. 
- Secure - The private key used for SAML Metadata is automatically generated and securely stored in Secrets Manager. 
- Customizable - After deploying the solution, you can connect to the CodeCommit Repo and further customize the SATOSA configuration as desired. Can be used with other SPs as well as a SAML-OIDC or SAML-Social Login solution. See [SATOSA docs](https://github.com/IdentityPython/SATOSA) for details. Commit changes to the repo and CodePipeline will automatically re-deploy.

Architecture:
![Architecture Diagram](saml-proxy.png "Architecture Diagram")



## Prerequisites
- An S3 bucket to store the cloudformation templates
- The appropriate IAM permissions to create all required infrastructure resources AND access the S3 bucket.
- An SSL certificate provisioned in AWS Certificate Manager - This will be used on the HTTPS listener of the Load Balancer
- (Optional) A Route53 hosted zone in the account, if you want to automatically create a resource record for the SAML Proxy. 

## Setup instructions
1. Create a certificate in AWS Certificate Manager, if you haven't yet

2. If you want to automatically create a DNS Record in Route53, ensure you already have a Hosted Zone created.

3. Download `code.zip` (an archive of the repo) and upload it to the S3 bucket

4. Create an S3 bucket and copy the files in the cloudformation directory into it

5. Download `cfn-templates/cfn-pipeline.yml`

6. In the CloudFormation console, [go to Create Stack](https://console.aws.amazon.com/cloudformation/home?region=us-east-1#/stacks/create/template), select **Upload a template file** and browse to the `cfn-pipeline.yml` template you downloaded in the previous step. Click Next.

7. For **Stack Name**, give the stack a meaningful name (i.e. saml-proxy). In the Parameters section, provide values for each paramter and click Next.

    **Note:** If you don't have a Route53 Hosted Zone in the account or use an external DNS provider, skip the **Route53 DNS** section.

8. At the **Configure stack options** page, scroll to the bottom and click Next.

9. At the **Review options** page, scroll to the bottom and check the box next to **I acknowledge that WS cloudFormation might create IAM resources** and click **Create stack**. 

10. In the Cloudformation Console, you can monitor the progress of the template deployment. When the deployment is complete, You can click the **Outputs** tab, then click the link next the **PipelineUrl** to be taken to the CodePipeline project.

11. In CodePipeline, watch the progress as the deployment. When the deployment completes, you can go to the Urls of the load balancer to view and download the SP and IdP metadata.


## Components
The project consists of 3 major sets of components:

### SATOSA Config
The Drupal-Restore Automation document orchestrates the step-by-step deployment of the Drupal infrastructure and restore from backups. It creates CloudFormation stacks and executes CodeBuild projects.

### CloudFormation Templates
CloudFormation templates are located in the `cloudformation` directory. Below are the templates, listed in order of deployment:
1. **cfn-pipeline**: Main template used to deploy the base CodePipeline project, code repository with code, ECR repo, and secrets. Also takes in SAML Proxy settings that will be used throughout the deployment.

2. **cfn-vpc**: Creates the VPC, subnets, and NAT Gateways. This is deployed by CodePipeline in the Deploy stage.

3. **cfn-ecs-fargate-cluster**:  Deploys the ECS Cluster, Load Balancer + Listener and Target Groups, ECS Service, and Task Definition. This is deployed by CodePipeline.



### CodeBuild Buildspecs
The buildspec files contain scripted operations needed when restoring the site from backup files. More details are below:
1. **buildspec-buildimage**: Builds the docker image using `docker/Dockerfile`. The Dockerfile pulls the latest SATOSA image from Docker Hub, adds the files in `satosa/config` to `/etc/satosa/config` and modifies to `CMD` to run `docker/write_metadata_key.sh` at container startup. This script will write the PRIVATE_KEY and METADATA_CERTIFICATE envrionment variables to files prior to starting the SATOSA server.

2. **buildspec-generatekeys**: Checks if the SecretsManager secrets that store the metadata private key and certificate contain values and, if not, generates a private key and certificate and stores them in the Secrets Manager Secrets. If the secrets already contain values, then this buildpec does nothing.

3. There is also a CodeBuild project and Buildspec built into the CodePipeline template named `GenerateClusterParameters`. This Buildspec is used to prepare a JSON file containing the parameter names and values that will be used as input to the `cfn-ecs-fargate-cluster` template. Though these paramters can be passed into [CodePipeline CloudFormation Actions](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/continuous-delivery-codepipeline-action-reference.html) dynamically using `ParameterOverrides`, there is a 1000 character limit and so this project works around that. Also, I couldn't find a way to use [`Fn::GetParam`](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/continuous-delivery-codepipeline-parameter-override-functions.html) to pass multiple input parameters into a single Parameter (i.e. ClusterSubnets). Because it's tightly coupled to the Pipeline, I opted to write this buildspec into the pipeline template itself, but might move it into the `buildspecs` folder later.


## Possible Future Enhancements
If time were infinite:
- Enhance the deployment of updated container images - Blue/Green deployment or something similar.
- Load testing and scale out - I didn't have time to test autoscaling.
- PR to put customizations into SATOSA so they don't need to be injected into the container image.
- ?

## Uninstall/Cleanup
| :warning: | Delete the stacks in the order listed below. Deleting cfn-pipeline.yml will remove the role used to deploy the other stacks. | 
|-|:-|

Most of this solution can be uninstalled by deleting the associated CloudFormation stacks.
1. If it exists, delete the `[StackName]-fargate` stack.
2. If it exists, delete the `[StackName]-vpc` stack.
3. Delete the stack that was created with `cfn-pipeline.yml`


Note that there are few artifacts that will cause `DELETE_FAILED` on the stacks. They will be left behind and must be cleaned up manually:
1. The ECR repository (named `[StackName]-image`).
2. The S3 bucket and code.zip file that was uploaded to it.
3. The artifacts S3 bucket created by the pipeline (`[StackName]-artifactbucket-randomstring`).
4. The load balancer logs S3 bucket created in the fargate stack (`[StackName]-fargate-loadbalancerlogsbucket-randomstring`)


## Helpful Links
- https://github.com/IdentityPython/SATOSA
- https://hub.docker.com/r/satosa/satosa
- https://github.com/awslabs/aws-cloudformation-templates/tree/master/aws/services/ECS

